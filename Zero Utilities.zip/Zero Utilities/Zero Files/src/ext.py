import os

def extensions(fileTypes, fileNames, i):
    split = os.path.splitext(fileNames[i])  # split file extension
    path = os.getcwd() + "/" + fileNames[i]
    ext = split[1]

    if os.path.isdir(path):
        fileTypes[i] = "Directory"
    else:
        if ext == "":
            fileTypes[i] = "Unknown file"
        elif ext == ".png":
            fileTypes[i] = "PNG Image"
        elif ext == ".jpg":
            fileTypes[i] = "JPG Image"
        elif ext == ".exe":
            fileTypes[i] = "Application"
        elif ext == ".mp4":
            fileTypes[i] = "MP4 Video"
        elif ext == ".mp3":
            fileTypes[i] = "MP3 Audio"
        elif ext == ".pyw":
            fileTypes[i] = "Python File"
        elif ext == ".py":
            fileTypes[i] = "Python File"
        elif ext == ".dll":
            fileTypes[i] = "App Extension"
        elif ext == ".lnk":
            fileTypes[i] = "Shortcut"
        elif ext == ".txt":
            fileTypes[i] = "Text File"
        elif ext == ".lnk":
            fileTypes[i] = "Shortcut"
        elif ext == ".zip":
            fileTypes[i] = "ZIP Folder"
        elif ext == ".7z":
            fileTypes[i] = "7Zip Folder"
        elif ext == ".apk":
            fileTypes[i] = "Android Package Kit"
        elif ext == ".ini":
            fileTypes[i] = "Configuration"
        elif ext == ".bat":
            fileTypes[i] = "Batch Script"
        elif ext == ".cs":
            fileTypes[i] = "C# Files"
        elif ext == ".jpeg":
            fileTypes[i] = "JPEG Image"
        elif ext == ".lua":
            fileTypes[i] = "LUA File"
        elif ext == ".iso":
            fileTypes[i] = "System Image"
        elif ext == ".msi":
            fileTypes[i] = "Windows Installer"
        elif ext == ".docx":
            fileTypes[i] = "Word Document"
        elif ext == ".xlsx":
            fileTypes[i] = "Excel Spreadsheet"
        elif ext == ".pptx":
            fileTypes[i] = "PowerPoint Presentation"
        elif ext == ".lnk":
            fileTypes[i] = "Shortcut"
        else:
            fileTypes[i] = ext.upper()[1:] + " File"
